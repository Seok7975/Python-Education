#덧셈과 뺄셈을 위한 함수를 선언함
def add(a, b):
    return a + b

def sub(a, b):
    return a - b