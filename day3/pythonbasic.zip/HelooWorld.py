print("Hello World!")
print("="*60)