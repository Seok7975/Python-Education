# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
""" 
a = 1
print(a+3)
print("Hello Spyder")
