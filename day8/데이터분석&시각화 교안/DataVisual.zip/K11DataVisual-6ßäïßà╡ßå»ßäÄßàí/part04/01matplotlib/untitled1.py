#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Mar 25 16:15:30 2024

@author: apple
"""

import matplotlib
print(matplotlib.get_cachedir())